import numpy as np
from scipy.optimize import curve_fit

# 给定数据
x_data = np.array([0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9])
y_data = np.array([0.2969, 0.6198, 0.8331, 0.908, 0.9304, 0.9373, 0.944, 0.947, 0.9503])

# 定义 ln 函数的形式
def ln_func(x, a, b):
    return a * np.log(x) + b

# 使用最小二乘法进行拟合
params, covariance = curve_fit(ln_func, x_data, y_data)

# 拟合参数
a_fit, b_fit = params

print("拟合参数 a:", a_fit)
print("拟合参数 b:", b_fit)
print(0.2889623597493018 *np.log(0.1)+1.0728663910395249)#np.log(1 + 0.0826 * np.log(3614.137 * t_choices)
