import sympy as sp
import numpy as np
from scipy.optimize import curve_fit


# 示例数据

x_data = np.array([2,4,6,8,10,14,17,20,25,30,35,40,44,46,50])
y_data = np.array([0.7081, 0.7728,0.8235,0.8616,0.8877, 0.9199,0.9357,0.9466,0.9579,0.9637, 0.9684,0.9718,0.9733,0.9740,0.9757])

# 定义对数函数作为拟合目标
def log_function(x, a, b):
    return np.log(a * x+b)

# 利用 curve_fit 进行拟合
initial_guess = [1.0, 2.0]  # 初始猜测参数
fit_params, covariance = curve_fit(log_function, x_data, y_data, p0=initial_guess)

# 提取拟合结果
a, b = fit_params

# 使用 SymPy 创建符号变量
x, a_sym, b_sym = sp.symbols('x a b')

# 构建对数函数的符号表达式
log_expr =   sp.ln(a_sym * x+b_sym)

# 用拟合参数替换符号变量
log_expr = log_expr.subs({a_sym: a, b_sym: b})

# 打印拟合的表达式
print("Fitted Expression:", log_expr)

print(np.log(0.01074*20+2.237289))#np.log(1 + 0.0826 * np.log(3614.137 * t_choices)

import math
result = np.log(2.7)
print(result,'---------------------------------------------')

# print((0.2889623597493018 * np.log(0.9)+ 1.0728663910395249))
print((0.2889623597493018 * np.log(0.2) + 1.0728663910395249 + 0.0826 * np.log(3614.137 * 10)) / 2)

import sympy as sp
import numpy as np
from scipy.optimize import curve_fit


# 示例数据

# x_data = np.array([0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9])
# y_data = np.array([0.37,0.692,0.849,0.907,0.928,0.935,0.940,0.942,0.943])  压缩率

x_data = np.array([2,4,6,8,10,12,14,16,18,20,30,40,50])

y_data = np.array([0.4234,
0.5369,
0.6365,
0.7096,
0.7621,
0.7977,
0.8244,
0.844,
0.8586,
0.8709,
0.8999,
0.9142,
0.9199,])



# 定义对数函数作为拟合目标
def log_function(x, a, b):
    return np.log(a * x+b)

# 利用 curve_fit 进行拟合
initial_guess = [1.0, 2.0]  # 初始猜测参数
fit_params, covariance = curve_fit(log_function, x_data, y_data, p0=initial_guess)

# 提取拟合结果
a, b = fit_params

# 使用 SymPy 创建符号变量
x, a_sym, b_sym = sp.symbols('x a b')

# 构建对数函数的符号表达式
log_expr =   sp.ln(a_sym * x+b_sym)

# 用拟合参数替换符号变量
log_expr = log_expr.subs({a_sym: a, b_sym: b})

# 打印拟合的表达式
print("Fitted Expression:", log_expr)

print(np.log(0.02056*20+1.811))#np.log(1 + 0.0826 * np.log(3614.137 * t_choices)

import math
result = np.log(2.7)
print(result)



