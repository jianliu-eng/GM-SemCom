import os
import cv2
import numpy as np
from skimage.metrics import structural_similarity as compare_ssim
import lpips
import torch

def jpeg2000_compression_ratio(input_image_path, output_image_path, quality=90):
    original_size = os.path.getsize(input_image_path)
    
    image = cv2.imread(input_image_path)
    cv2.imwrite(output_image_path, image, [cv2.IMWRITE_JPEG2000_COMPRESSION_X1000, quality * 10])
    
    compressed_size = os.path.getsize(output_image_path)
    
    compression_ratio = (compressed_size / original_size) * 100
    
    return compression_ratio

def jpeg2000_compression_ssim(original_image, compressed_image):
    original_image_gray = cv2.cvtColor(original_image, cv2.COLOR_BGR2GRAY)
    compressed_image_gray = cv2.cvtColor(compressed_image, cv2.COLOR_BGR2GRAY)

    ssim_value, _ = compare_ssim(original_image_gray, compressed_image_gray, full=True)

    return ssim_value


def calculate_psnr(original_image, compressed_image):
    psnr_value = cv2.PSNR(original_image, compressed_image)
    return psnr_value

def calculate_lpips(original_image, compressed_image):
    loss_fn = lpips.LPIPS(net="alex")

    original_image = torch.tensor(np.array(original_image)).permute(2, 0, 1).unsqueeze(0).float() / 255.0
    compressed_image = torch.tensor(np.array(compressed_image)).permute(2, 0, 1).unsqueeze(0).float() / 255.0
    print(original_image.size())
    lpips_value = loss_fn(original_image, compressed_image)
    return lpips_value.item()


def SNR_to_noise(snr):
    snr = 10 ** (snr / 10)
    noise_std = 1 / np.sqrt(2 * snr)
    return noise_std


def AWGN(compressed_image, n_var, device):
    compressed_image = torch.tensor(compressed_image).to(device)
    noise = torch.normal(0, torch.sqrt(torch.tensor(n_var)), size=compressed_image.shape).to(device)
    Rx_sig = compressed_image + noise
    return Rx_sig .cpu().numpy().astype(np.uint8)  # 将结果转换回原来的格式（比如NumPy数组）


# 示例用法：
input_image_path = '/home/liujian/diffae-master/output.jpg'
output_image_path = '/home/liujian/diffae-master/compressed_image.jp2'
quality = 7
compression_ratio = jpeg2000_compression_ratio(input_image_path, output_image_path, quality)
print(f"JPEG2000压缩率为: {compression_ratio:.2f}%")

original_image = cv2.imread(input_image_path)
print
compressed_image = cv2.imread(output_image_path)

device = 'cpu'
SNR = 5
noise_std = SNR_to_noise(SNR)

noisecompressed_image = AWGN(compressed_image, noise_std, device)
output_noisecompressed_image_path = '/home/liujian/diffae-master/JPEG2000/noisecompressed_image.png'
cv2.imwrite(output_noisecompressed_image_path, noisecompressed_image)


ssim_value = jpeg2000_compression_ssim(original_image, noisecompressed_image)
print(f"JPEG2000压缩后的SSIM指标为: {ssim_value}")

psnr_value = calculate_psnr(original_image, noisecompressed_image)
print(f"JPEG2000压缩后的PSNR指标为: {psnr_value}")

# lpips_value = calculate_lpips(original_image, noisecompressed_image)
# print(f"LPIPS指标为: {lpips_value}")
