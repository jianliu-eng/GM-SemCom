from PIL import Image
import subprocess
import torch
import torchvision.transforms as transforms

# 定义图像转换
transform = transforms.Compose([
    transforms.ToPILImage(),
    transforms.Resize((256, 256)),  # 调整图像尺寸
    transforms.ToTensor()           # 转换为张量
])

# 加载和预处理图像
input_image_path = "/home/liujian/diffae-master/test/output.jpg"
input_image = Image.open(input_image_path)
input_tensor = transform(input_image).unsqueeze(0)  # 添加批次维度

# 保存预处理后的图像为临时文件
temp_image_path = "temp_input.png"
input_image.save(temp_image_path)

# 使用 bpgenc 进行压缩
output_image_path = "output.bpg"
subprocess.run(["bpgenc", "-m", "9", "-o", output_image_path, temp_image_path])

# 加载压缩后的图像
compressed_image = Image.open(output_image_path)
compressed_tensor = transform(compressed_image).unsqueeze(0)  # 添加批次维度

# 使用 PyTorch 进行图像处理，这里只是一个示例
# 你可以继续使用 PyTorch 对图像进行处理或者传入模型进行推理

# 示例：计算两个图像之间的均方误差
mse_loss = torch.nn.MSELoss()
loss = mse_loss(input_tensor, compressed_tensor)

print("MSE Loss:", loss.item())
