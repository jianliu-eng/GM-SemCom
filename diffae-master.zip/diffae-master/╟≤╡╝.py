import sympy as sp

# 定义变量
x, y = sp.symbols('x y')

# 定义函数
f = sp.log(1 + y, 2) * sp.ln(1 + 0.08267 * sp.ln(3614.1373 * x)) - y**2 / 900 

# 求一阶偏导数
df_dx = sp.diff(f, x)
df_dy = sp.diff(f, y)

print("一阶偏导数 df/dx:", df_dx)
print("一阶偏导数 df/dy:", df_dy)

# 求二阶偏导数
d2f_dx2 = sp.diff(df_dx, x)
d2f_dy2 = sp.diff(df_dy, y)
d2f_dxdy = sp.diff(df_dx, y)

print("二阶偏导数 d^2f/dx^2:", d2f_dx2)
print("二阶偏导数 d^2f/dy^2:", d2f_dy2)
print("二阶偏导数 d^2f/dxdy:", d2f_dxdy)

# 解一阶偏导数等于零的方程组，并添加限制条件
equations = [sp.Eq(df_dx, 0), sp.Eq(df_dy, 0)]
solution = sp.solveset(equations, [x, y], domain=sp.Interval(0, 60) * sp.Interval(1, 5))

# 计算二阶偏导数的行列式
determinant = d2f_dx2 * d2f_dy2 - d2f_dxdy**2 

print("一阶导数为零的点:", solution)
print("二阶偏导数的行列式:", determinant)

# 判断是否存在最大值
if all(isinstance(sol[x], sp.numbers.Float) and isinstance(sol[y], sp.numbers.Float) for sol in solution):
    if determinant.evalf(subs={x: solution.args[0][0], y: solution.args[0][1]}) > 0:
        print("存在最大值")
    else:
        print("不存在最大值")
else:
    print("无法判断")

