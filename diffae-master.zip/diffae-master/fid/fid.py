import torch_fidelity

image_folder = '/home/liujian/UNIT-DDPM-Unofficial/datasets/cycleganrealfake/ood64/w2s/fake'  #w2s 
datasetpath = '/home/liujian/UNIT-DDPM-Unofficial/datasets/cycleganrealfake/ood64/s2w/real'   #summer 原图
print("cyclegan summer Calculate FID score...")
fid = 0
metrics = torch_fidelity.calculate_metrics(input1=image_folder, input2=datasetpath, cuda=0, isc=False, fid=True, kid=False, verbose=False)
print(metrics)

image_folder = '/home/liujian/UNIT-DDPM-Unofficial/datasets/cycleganrealfake/ood64/w2s/real'   #winter 原图
datasetpath = '/home/liujian/UNIT-DDPM-Unofficial/datasets/cycleganrealfake/ood64/s2w/fake'    #s2w 
fid = 0
metrics = torch_fidelity.calculate_metrics(input1=image_folder, input2=datasetpath, cuda=0, isc=False, fid=True, kid=False, verbose=False)
print(metrics)


#unitddpm---------------------------------------------------------------------
image_folder = '/home/liujian/UNIT-DDPM-Unofficial/datasets/unitddpm/ood64/w2s/fake'  #w2s 
datasetpath = '/home/liujian/UNIT-DDPM-Unofficial/datasets/cycleganrealfake/ood64/s2w/real'   #summer 原图
metrics = torch_fidelity.calculate_metrics(input1=image_folder, input2=datasetpath, cuda=0, isc=False, fid=True, kid=False, verbose=False)
print("unitddim Calculate FID score...")
print(metrics)

image_folder = '/home/liujian/UNIT-DDPM-Unofficial/datasets/unitddpm/ood64/w2s/real'   #winter 原图
datasetpath = '/home/liujian/UNIT-DDPM-Unofficial/datasets/cycleganrealfake/ood64/w2s/real'    #s2w 

fid = 0
metrics = torch_fidelity.calculate_metrics(input1=image_folder, input2=datasetpath, cuda=0, isc=False, fid=True, kid=False, verbose=False)
print(metrics)

#our---------------------------------------------------------------------
image_folder = '/home/liujian/UNIT-DDPM-Unofficial/datasets/adaptiveDDIMrealfake/ood64/w2s/fake'  #w2s 
datasetpath = '/home/liujian/UNIT-DDPM-Unofficial/datasets/cycleganrealfake/ood64/s2w/real'   #summer 原图
metrics = torch_fidelity.calculate_metrics(input1=image_folder, input2=datasetpath, cuda=0, isc=False, fid=True, kid=False, verbose=False)
print("adptiveddim Calculate FID score...")
print(metrics)

image_folder = '/home/liujian/UNIT-DDPM-Unofficial/datasets/cycleganrealfake/ood64/w2s/real'   #winter 原图
datasetpath = '/home/liujian/UNIT-DDPM-Unofficial/datasets/adaptiveDDIMrealfake/ood64/s2w/fake'    #s2w 

fid = 0
metrics = torch_fidelity.calculate_metrics(input1=image_folder, input2=datasetpath, cuda=0, isc=False, fid=True, kid=False, verbose=False)
print(metrics)